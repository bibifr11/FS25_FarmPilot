-- ============================================================================================================
-- FarmPilot : WaitForCallTaskFieldPark.lua
-- Complément de WaitForCallTask (tâche AutoDrive d'origine) : la benne qui attend l'appel de la moissonneuse /
-- l'ensileuse se gare d'abord dans le champ, hors du passage, au lieu d'attendre au point du champ (l'entrée).
--
-- Historique : 25/10 (champ complet, recul par la route), 26/10 et 26/10 17:48
-- (le 6205 traversait 100 m de maïs pour une place de l'autre côté ; aucune place trouvée), 27/10 18:20
-- (942 en travers de l'entrée, gênant tout le monde), 27/10 20:35 (recul jusque dans le champ d'en face).
--
-- Règle :
-- - à l'arrivée au champ (remorques vides), une place libre est cherchée dans le champ (ADFieldPark,
--   FieldParkModule.lua), un pas de recherche par image, puis un trajet propre vers elle (direct, mémorisé, ou
--   pathfinder d'AutoDrive) ; un trajet qui traverse la culture est refusé ;
-- - déjà garée à une bonne place (partie sauvegardée) : elle y reste ; chargée (retour d'une moissonneuse) : elle
--   reste où elle est ;
-- - en file derrière une autre benne garée : elle prend sa place quand elle part ;
-- - aucune place pour l'instant : attente au bord de la route avant l'entrée (WaitForCallTaskRoadside.lua), ou
--   petit recul si le nez est dans le champ, puis nouvel essai plus tard ;
-- - 10/11, moissonneuse : le trajet suit le bord du champ depuis l'entrée jusqu'à la place (bande coupée) ; virage
--   trop large pour y entrer (nez déjà dans le champ) : recul de quelques mètres d'abord ; bande étroite sans trajet
--   le long du bord : pas de pathfinder d'AutoDrive, place suivante ; reculée par la route faute de place : retour au
--   point du champ par le réseau dès qu'une place existe.
-- - 11/11 (champ 56), moissonneuse : arrêtée sur le chemin avant l'entrée faute de place atteignable, ou reculée par la
--   route : elle ne retourne au point du champ qu'avec une place ET un trajet propre depuis l'entrée ; sinon elle
--   attend sur le chemin (au bord de la route si possible), jamais à l'entrée.
-- - 11/11 : aucune machine de récolte au travail dans ce champ (garée ailleurs, pas encore arrivée) : même attente,
--   mais le HUD et le journal le disent (« Pas de machine de récolte dans ce champ »), pas « Aucune place ».
-- Pas pour un véhicule conduit par Courseplay (il ne fait que passer).
--
-- Branché par une ligne dans WaitForCallTask.lua : setUp, update, abort, finished, getInfoText, getI18nInfo.
-- ============================================================================================================

-- ------------------------------------------------------------------------------------------------------------
-- Réglages / constantes
-- ------------------------------------------------------------------------------------------------------------
-- states used to park inside the field before waiting (see ADFieldPark, scripts/Modules/FieldParkModule.lua)
WaitForCallTask.STATE_CHECK = 1
WaitForCallTask.STATE_PATHPLANNING = 2
WaitForCallTask.STATE_DRIVING = 3
WaitForCallTask.STATE_WAITING = 4
WaitForCallTask.STATE_SEARCHING = 5
WaitForCallTask.STATE_BACKING_OFF = 6
WaitForCallTask.STATE_TO_ENTRANCE = 7 -- beside the road, a place is free in the field: back on the network to the field point first
WaitForCallTask.NO_PLACE_AHEAD_VALID = 10000 -- ms: stopped on the road before the entrance this recently (DriveToDestinationTask)

-- no spot in the field yet and the nose in the field (the AutoDrive waiting point can be at the very corner):
-- back off a little, out of the way of the harvester, a bit more on the next try
WaitForCallTask.BACK_OFF_DISTANCES = {2, 3}
WaitForCallTask.BACK_OFF_TIMEOUT = 15000

-- (11/11) résultats de recherche qui ne sont pas un manque de place : aucune machine de récolte au travail dans ce
-- champ (moissonneuse garée ailleurs, pas encore arrivée). Le HUD et le journal le disent tel quel.
WaitForCallTask.HARVESTER_AWAY = {
    ["no harvester"] = true,
    ["harvester not in the field yet"] = true,
    ["harvester not in the field ahead"] = true
}

-- ------------------------------------------------------------------------------------------------------------
-- Mise en place (WaitForCallTask:setUp)
-- ------------------------------------------------------------------------------------------------------------
function WaitForCallTask:setUpFieldPark()
    self.state = WaitForCallTask.STATE_WAITING
    self.failedPathFinder = 0
    self.backOffCount = 0
    -- not when Courseplay drives this vehicle: it only passes through and Courseplay takes it over in the field
    local cpDriven = AutoDrive:getIsCPActive(self.vehicle) or self.vehicle.ad.restartCP == true
    if ADFieldPark ~= nil and ADFieldPark.isEnabled() and self.vehicle.ad.trafficYieldModule ~= nil and not cpDriven then
        self.state = WaitForCallTask.STATE_CHECK
        self.checkTimer = AutoDriveTON:new()
        -- 11/11 : arrêtée sur le chemin avant l'entrée faute de place atteignable (DriveToDestinationTaskFieldEntrance.lua) :
        -- elle cherche de nouveau depuis le point du champ, sans y aller, et n'y va qu'avec un trajet propre
        local ahead = self.vehicle.ad.noPlaceAhead
        self.vehicle.ad.noPlaceAhead = nil
        if ahead ~= nil and (g_time or 0) - ahead.time < WaitForCallTask.NO_PLACE_AHEAD_VALID then
            self.noPlaceOrigin = ahead.origin
            self.noPlaceRoadside = true
            self.noPlaceTimer = 0
            self.routeBackOffDone = true
            self.stoppedBeforeEntrance = true
        end
    end
end

-- already standing at a good place (parked before the savegame was saved): stay, and hold this place for the
-- others, which queue behind
function WaitForCallTask:stayParked(module)
    local good, spot = ADFieldPark.isGoodWaitingPlace(self.vehicle)
    if not good then
        module:log("field park: current place not kept: %s", tostring(spot))
        return false
    end
    module:log("field park: already a good waiting place, staying here")
    self.parkedSpot = spot
    ADFieldPark.setParked(self.vehicle, spot, false)
    return true
end

-- ------------------------------------------------------------------------------------------------------------
-- Fonction principale : déroulé de l'attente (WaitForCallTask:update)
-- ------------------------------------------------------------------------------------------------------------
function WaitForCallTask:updateFieldPark(dt)
    if self.state == WaitForCallTask.STATE_CHECK then
        -- let the vehicle come to a stop before looking around
        if self.checkTimer:timer(true, 1000, dt) then
            local module = self.vehicle.ad.trafficYieldModule
            if self:hasLoad() then
                -- field parking is only for the arrival at the field (empty trailers). After unloading a harvester the
                -- unloader already stands on the harvested side: stay here
                module:log("field park: loaded, back from a harvester, staying here")
                self.loaded = true
                self.state = WaitForCallTask.STATE_WAITING
            elseif self:stayParked(module) then
                self.state = WaitForCallTask.STATE_WAITING
            elseif self:goRoadsideIfFieldFull() then
                -- the field already holds its unloaders: wait beside the road
            else
                -- backed off along the road because the field had no place yet: looks again from the entrance
                self.search = ADFieldPark.newSearch(self.vehicle, self.noPlaceRoadside and self.noPlaceOrigin or nil)
                self.state = WaitForCallTask.STATE_SEARCHING
            end
        end
        self:hold(dt)
    elseif self.state == WaitForCallTask.STATE_SEARCHING then
        -- one step of the search per frame (see ADFieldPark.searchStep)
        local spots = ADFieldPark.searchStep(self.search)
        if spots ~= nil then
            if self.search.result ~= nil then
                self.vehicle.ad.trafficYieldModule:log("field park: %s", self.search.result)
            end
            local search = self.search
            self.search = nil
            self.harvesterAway = WaitForCallTask.HARVESTER_AWAY[search.result or ""] == true
            if self.probeFromRoadside then
                self.probeFromRoadside = nil
                if #spots > 0 and not search.waitSense and self:hasWayFromEntrance(search, spots) then
                    print(string.format("[AD-File] %s: une place est libre dans le champ maintenant, j'y vais (%d places)", tostring(self.vehicle:getName()), #spots))
                    self.noPlaceRoadside = nil
                    self:leaveRoadside()
                else
                    self.vehicle.ad.trafficYieldModule:log("field park: still no place in the field, staying beside the road")
                    self.state = WaitForCallTask.STATE_WAITING
                end
            elseif search.waitSense and #spots == 0 then
                -- the sense of the first headland is not known yet: wait beside the road until it is
                print(string.format("[AD-File] %s: sens de la 1re fourriere pas encore connu, attente au bord de la route", tostring(self.vehicle:getName())))
                self:goRoadside(search.harvester)
            elseif self.noPlaceRoadside and not search.chopper and self:isAwayFromEntrance() then
                -- 10/11, combine: backed off along the route while the field had no place, a place exists now:
                -- back on the network to the field point first, the way along the border starts there.
                -- 11/11 (champ 56) : seulement avec un trajet propre depuis l'entrée ; sinon elle reste sur le chemin
                -- (au bord de la route si une place y est atteignable) et cherche de nouveau plus tard
                if #spots > 0 and not search.waitSense and self:hasWayFromEntrance(search, spots) then
                    print(string.format("[AD-File] %s: une place est libre dans le champ maintenant, j'y vais (%d places)", tostring(self.vehicle:getName()), #spots))
                    self.noPlaceRoadside = nil
                    self:leaveRoadside()
                elseif self.stoppedBeforeEntrance and search.harvester ~= nil and not self.roadsideTried and (self.parkedSpot == nil or not self.parkedSpot.roadside) then
                    self.roadsideTried = true
                    print(string.format("[AD-File] %s: pas de place atteignable dans le champ, attente sur le chemin avant l'entree", tostring(self.vehicle:getName())))
                    self:goRoadside(search.harvester)
                else
                    self.vehicle.ad.trafficYieldModule:log("field park: still no place reachable in the field, waiting on the road")
                    self.state = WaitForCallTask.STATE_WAITING
                    self.retryTime = 0
                end
            else
                self.spots = spots
                self.spotIndex = 0
                self:planToNextSpot()
            end
        end
        self:hold(dt)
    elseif self.state == WaitForCallTask.STATE_PATHPLANNING then
        local pathFinder = self.vehicle.ad.pathFinderModule
        if pathFinder:hasFinished() then
            local wayPoints = pathFinder:getPath()
            self.vehicle.ad.trafficYieldModule:log("field park: pathfinder for spot %d: search %.1f s, smoothing %.1f s",
                self.spotIndex, self.planningTime / 1000, (self.smoothingTime or 0) / 1000)
            if wayPoints == nil or #wayPoints <= 1 then
                self.failedPathFinder = self.failedPathFinder + 1
                self.vehicle.ad.trafficYieldModule:log("field park: no path to spot %d", self.spotIndex)
                self:planToNextSpot()
            elseif pathFinder.fallBackMode3 or self:pathCrossesCrop(wayPoints, pathFinder) then
                -- the pathfinder only got there by driving through the crop: not worth it. Lifting the field
                -- restriction (fallback modes 1 and 2) is normal here: the unloader waits outside the field.
                -- Its grid is coarse and follows the avoidFruit setting: the route is checked again every meter
                -- (26/10: the 6205 crossed 100 m of maize to a place on the far side)
                self.failedPathFinder = self.failedPathFinder + 1
                self.vehicle.ad.trafficYieldModule:log("field park: path to spot %d crosses the crop, rejected", self.spotIndex)
                print(string.format("[AD-File] %s: le trajet vers la place %d traverse la culture, refuse", tostring(self.vehicle:getName()), self.spotIndex))
                self:planToNextSpot()
            else
                wayPoints = ADFieldPark.appendLeadIn(wayPoints, self.leadIn)
                -- remembered for the next unloaders only when it ends along the border
                self.plannedPath = self.leadIn ~= nil and wayPoints or nil
                self.vehicle.ad.drivePathModule:setWayPoints(wayPoints)
                self.state = WaitForCallTask.STATE_DRIVING
            end
            if self.state ~= WaitForCallTask.STATE_DRIVING then
                self:hold(dt)
            end
        elseif pathFinder.isFinished and self.smoothingTime ~= nil and self.smoothingTime > ADFieldPark.SMOOTHING_TIMEOUT then
            -- path found, its smoothing does not end: give up this spot
            pathFinder:reset()
            self.vehicle.ad.trafficYieldModule:log("field park: path to spot %d found in %.1f s, smoothing not done after %.1f s, next spot",
                self.spotIndex, self.planningTime / 1000, self.smoothingTime / 1000)
            self:planToNextSpot()
            self:hold(dt)
        elseif not pathFinder.isFinished and self.planningTime > ADFieldPark.PLANNING_TIMEOUT then
            -- the pathfinder can search for a very long time: give up this spot
            pathFinder:reset()
            self.vehicle.ad.trafficYieldModule:log("field park: no path to spot %d in time", self.spotIndex)
            self:planToNextSpot()
            self:hold(dt)
        elseif pathFinder.isFinished then
            -- path found: the smoothing has its own time
            self.smoothingTime = (self.smoothingTime or 0) + dt
            pathFinder:update(dt)
            self:hold(dt)
        else
            self.planningTime = self.planningTime + dt
            pathFinder:update(dt)
            self:hold(dt)
        end
    elseif self.state == WaitForCallTask.STATE_BACKING_OFF then
        local x, _, z = ADTrafficYieldModule.getPosition(self.vehicle)
        self.backOffTime = self.backOffTime + dt
        local backed = MathUtil.vector2Length(x - self.backOffStart.x, z - self.backOffStart.z)
        local target = self.backOffTargets ~= nil and self.backOffTargets[self.backOffIndex] or nil
        if backed >= self.backOffDistance or self.backOffTime > self.backOffTimeout
            or (self.backOffTargets ~= nil and target == nil) then
            self.vehicle.ad.trafficYieldModule:log("field park: backed off %.1f m%s", backed, self.backOffTargets ~= nil and " along the route" or "")
            if self.backOffTargets ~= nil then
                -- back on the road: the roadside places are looked for again from here
                self.backOffTargets = nil
                self.vehicle.ad.specialDrivingModule:releaseVehicle()
                self.state = WaitForCallTask.STATE_CHECK
                self.checkTimer = AutoDriveTON:new()
            elseif self.turnBackOff then
                -- backed off to turn into the cut strip: the place is looked for again from here
                self.turnBackOff = nil
                self.state = WaitForCallTask.STATE_CHECK
                self.checkTimer = AutoDriveTON:new()
            else
                self.state = WaitForCallTask.STATE_WAITING
                self.retryTime = 0
            end
            self:hold(dt)
        elseif self.backOffTargets ~= nil and backed > WaitForCallTask.ROUTE_BACK_OFF_MIN
            and AutoDrive.checkIsOnField(x, getTerrainHeightAtWorldPos(g_currentMission.terrainRootNode, x, 0, z), z) then
            -- 27/10 20:35 (it backed into the field opposite): backing along the route with a
            -- trailer drifts; as soon as the train is on a field again (the one opposite the entrance), it stops there
            self.vehicle.ad.trafficYieldModule:log("field park: backed off %.1f m along the route, on a field: stopping here", backed)
            print(string.format("[AD-File] %s: je recule sur un champ, j'arrete la (%.0f m)", tostring(self.vehicle:getName()), backed))
            self.backOffTargets = nil
            self.vehicle.ad.specialDrivingModule:releaseVehicle()
            self.state = WaitForCallTask.STATE_CHECK
            self.checkTimer = AutoDriveTON:new()
            self:hold(dt)
        elseif self.backOffTargets ~= nil then
            if self.vehicle.ad.trafficYieldModule:reverseTowards(dt, target) then
                self.backOffIndex = self.backOffIndex + 1
            end
        else
            self.vehicle.ad.specialDrivingModule:driveReverse(dt, 4, 1, false)
        end
    elseif self.state == WaitForCallTask.STATE_TO_ENTRANCE then
        if self.vehicle.ad.drivePathModule:isTargetReached() then
            self.state = WaitForCallTask.STATE_CHECK
            self.checkTimer = AutoDriveTON:new()
            self:hold(dt)
        elseif ADFieldPark.holdForExit(self.vehicle, dt, "sur la route") then
            -- a full one drives out by this entrance: it passes first
        else
            self.vehicle.ad.drivePathModule:update(dt)
        end
    elseif self.state == WaitForCallTask.STATE_DRIVING then
        if self.vehicle.ad.drivePathModule:isTargetReached() then
            self.parkedSpot = self.spots ~= nil and self.spots[self.spotIndex] or nil
            ADFieldPark.setParked(self.vehicle, self.parkedSpot, false)
            ADFieldPark.rememberSpot(self.vehicle, self.parkedSpot, self.plannedPath, self.planStart)
            self.moveUpTimer = 0
            self.state = WaitForCallTask.STATE_WAITING
            self:hold(dt)
        else
            self.vehicle.ad.drivePathModule:update(dt)
        end
    else
        -- beside the road: into the field when a place is free there, else closer to the entrance
        if self.parkedSpot ~= nil and self.parkedSpot.roadside and self.noPlaceRoadside then
            -- beside the road because the field had no place yet: the search runs again from the entrance it came
            -- to, without driving there; it goes in only when a place exists
            self.retryTime = nil
            self.noPlaceTimer = (self.noPlaceTimer or 0) + dt
            if self.noPlaceTimer > WaitForCallTask.NO_PLACE_RETRY then
                self.noPlaceTimer = 0
                self.search = ADFieldPark.newSearch(self.vehicle, self.noPlaceOrigin)
                self.probeFromRoadside = true
                self.state = WaitForCallTask.STATE_SEARCHING
                self:hold(dt)
                return
            end
        elseif self.parkedSpot ~= nil and self.parkedSpot.roadside then
            self.moveUpTimer = (self.moveUpTimer or 0) + dt
            if self.moveUpTimer > WaitForCallTask.MOVE_UP_CHECK then
                self.moveUpTimer = 0
                if self:moveUpRoadside() then
                    self:hold(dt)
                    return
                end
            end
        end
        -- parked in line behind another unloader in the field: takes its place when it leaves
        if self.parkedSpot ~= nil and self.parkedSpot.aheadVehicle ~= nil then
            self.moveUpTimer = (self.moveUpTimer or 0) + dt
            if self.moveUpTimer > WaitForCallTask.MOVE_UP_CHECK then
                self.moveUpTimer = 0
                if self:moveUp() then
                    self:hold(dt)
                    return
                end
            end
        end
        -- no spot reachable yet (crop still standing at the entrance, harvester not started...): look again later
        if self.retryTime ~= nil then
            self.retryTime = self.retryTime + dt
            if self.retryTime > ADFieldPark.RETRY_DELAY then
                self.retryTime = nil
                self.state = WaitForCallTask.STATE_CHECK
            end
        end
        self:hold(dt)
    end
end

-- ------------------------------------------------------------------------------------------------------------
-- En file derrière une autre benne : prendre sa place
-- ------------------------------------------------------------------------------------------------------------
WaitForCallTask.MOVE_UP_CHECK = 2000 -- ms between two checks of the place ahead in the line

-- the unloader ahead in the line left its place: take it (the whole train centred on the same footprint)
function WaitForCallTask:moveUp()
    local spot = self.parkedSpot
    local aheadSpot = spot.ahead
    if ADFieldPark.parked[spot.aheadVehicle] == aheadSpot or aheadSpot == nil or aheadSpot.cx == nil then
        return false
    end
    local front, rear = ADTrafficYieldModule.getTrainExtents(self.vehicle)
    local length = front + rear
    local halfW = ADTrafficYieldModule.getWidth(self.vehicle) / 2 + 0.5
    local probe = {vehicle = self.vehicle, halfW = halfW, halfL = length / 2 + 0.5}
    if ADFieldPark.overlapsTakenSpot(probe, aheadSpot.cx, aheadSpot.cz, aheadSpot.dirX, aheadSpot.dirZ) then
        -- someone else is already going there
        spot.aheadVehicle = nil
        return false
    end
    local shift = length / 2 - front
    local tx, tz = aheadSpot.cx + aheadSpot.dirX * shift, aheadSpot.cz + aheadSpot.dirZ * shift
    local newSpot = {
        x = tx, y = getTerrainHeightAtWorldPos(g_currentMission.terrainRootNode, tx, 0, tz), z = tz,
        dirX = aheadSpot.dirX, dirZ = aheadSpot.dirZ,
        cx = aheadSpot.cx, cz = aheadSpot.cz, halfL = probe.halfL,
        queued = true, ahead = aheadSpot.ahead, aheadVehicle = aheadSpot.aheadVehicle, harvester = spot.harvester,
        memo = aheadSpot.memo, sense = aheadSpot.sense
    }
    print(string.format("[AD-File] %s: la benne de devant est partie, avance a sa place (%.0f,%.0f)", tostring(self.vehicle:getName()), tx, tz))
    self.parkedSpot = nil
    self.spots = {newSpot}
    self.spotIndex = 0
    self:planToNextSpot()
    return true
end

-- ------------------------------------------------------------------------------------------------------------
-- Choix de la place et trajet
-- ------------------------------------------------------------------------------------------------------------
-- starts the path planning to the next candidate spot, or waits here when none is left
function WaitForCallTask:planToNextSpot()
    local module = self.vehicle.ad.trafficYieldModule
    self.spotIndex = self.spotIndex + 1
    local spot = self.spots ~= nil and self.spots[self.spotIndex] or nil
    if spot == nil or self.spotIndex > ADFieldPark.MAX_TRIES then
        ADFieldPark.setParked(self.vehicle, nil)
        if self.spotIndex == 1 then
            module:log("field park: no free ground found, waiting here")
        else
            module:log("field park: no clean path to a free spot, waiting here")
        end
        self.state = WaitForCallTask.STATE_WAITING
        self.retryTime = 0
        local roadside = self.spots ~= nil and self.spots[1] ~= nil and self.spots[1].roadside
        if self.spotIndex == 1 and not roadside and self.noPlaceRoadside then
            -- already backed off on the road for that reason: just wait and look again later, no more backing off
            return
        end
        if self.spotIndex == 1 and not roadside and not self.ignoreCapacity and not self.loaded then
            -- 27/10 18:20 (942 across the entrance, in everybody's way): the job has just started, no harvested
            -- ground to park on yet: it does not wait at the entrance in everybody's way, it waits beside the road
            -- before the entrance and looks again from there (see probeFromRoadside)
            local x, _, z = ADTrafficYieldModule.getPosition(self.vehicle)
            local harvester = ADFieldPark.findHarvester(self.vehicle, x, z)
            if harvester ~= nil then
                local dx, dz = ADTrafficYieldModule.getDirection(self.vehicle)
                self.noPlaceOrigin = {x = x, z = z, dx = dx, dz = dz}
                self.noPlaceRoadside = true
                self.noPlaceTimer = 0
                if self.harvesterAway then
                    print(string.format("[AD-File] %s: la machine de recolte n'est pas dans ce champ, attente au bord de la route avant l'entree", tostring(self.vehicle:getName())))
                else
                    print(string.format("[AD-File] %s: aucune place dans le champ pour l'instant, attente au bord de la route avant l'entree", tostring(self.vehicle:getName())))
                end
                self:goRoadside(harvester)
                if self.spots == nil or #self.spots == 0 then
                    if not self:startRouteBackOff() then
                        self:startBackOff()
                    end
                end
                return
            end
            if self.harvesterAway and not self.harvesterAwayLogged then
                self.harvesterAwayLogged = true
                print(string.format("[AD-File] %s: aucune machine de recolte au travail pour ce champ, attente ici", tostring(self.vehicle:getName())))
            end
        end
        if roadside and self.noPlaceRoadside and self:isAwayFromEntrance() then
            -- 11/11 : déjà sur le chemin avant l'entrée, aucune place au bord de la route atteignable d'ici : elle
            -- attend là (pas de recul) et cherche de nouveau plus tard
            return
        end
        if roadside and self:startRouteBackOff() then
            return
        elseif roadside and not self.ignoreCapacity then
            -- backed off already and still nothing: the entrance stays free, a place in the field behind the others
            self.ignoreCapacity = true
            self.state = WaitForCallTask.STATE_CHECK
            self.checkTimer = AutoDriveTON:new()
            return
        end
        self:startBackOff()
        return
    end
    module:log("field park: spot %d found at x=%.0f z=%.0f heading %.0f°%s", self.spotIndex, spot.x, spot.z, math.deg(math.atan2(spot.dirX, spot.dirZ)), spot.queued and " (in line with a parked unloader)" or "")
    -- taken for the others while this unloader drives there (order of arrival along the border)
    ADFieldPark.setParked(self.vehicle, spot, true)
    local x, _, z = ADTrafficYieldModule.getPosition(self.vehicle)
    local dx, dz = ADTrafficYieldModule.getDirection(self.vehicle)
    self.planStart = {x = x, z = z, dx = dx, dz = dz}
    self.plannedPath = nil
    -- same start and same stop as the first unloader of this field: its path
    local wayPoints = ADFieldPark.getMemoPath(self.vehicle, spot)
    if wayPoints ~= nil then
        module:log("field park: remembered path to spot %d, %d points", self.spotIndex, #wayPoints)
        self.plannedPath = wayPoints
        self.vehicle.ad.drivePathModule:setWayPoints(wayPoints)
        self.state = WaitForCallTask.STATE_DRIVING
        return
    end
    -- 10/11, combine: the way follows the border from here to the place on the strip it has cut
    local combine = not spot.roadside and ADFieldPark.isCombineJob(self.vehicle)
    if combine then
        wayPoints = ADFieldPark.findApproach(self.vehicle, spot)
        if wayPoints ~= nil then
            self.leadIn = nil
            self.plannedPath = wayPoints
            self.vehicle.ad.drivePathModule:setWayPoints(wayPoints)
            self.state = WaitForCallTask.STATE_DRIVING
            return
        end
    end
    -- the last part follows the border: the whole train, trailers included, stops aligned with it
    local target, leadIn = ADFieldPark.getLeadIn(self.vehicle, spot)
    self.leadIn = leadIn
    if leadIn ~= nil then
        module:log("field park: lead-in along the border, %d points to spot %d", #leadIn, self.spotIndex)
    end
    wayPoints = ADFieldPark.findDirectPath(self.vehicle, target)
    if wayPoints ~= nil then
        wayPoints = ADFieldPark.appendLeadIn(wayPoints, leadIn)
        self.plannedPath = leadIn ~= nil and wayPoints or nil
        module:log("field park: direct path to spot %d, %d points", self.spotIndex, #wayPoints)
        self.vehicle.ad.drivePathModule:setWayPoints(wayPoints)
        self.state = WaitForCallTask.STATE_DRIVING
        return
    end
    if spot.roadside then
        -- the AutoDrive pathfinder may turn in the field: beside the road only with a direct path
        module:log("field park: no direct path to roadside spot %d without the field, next one", self.spotIndex)
        self:planToNextSpot()
        return
    end
    if combine then
        -- the nose already in the field, the turn into the cut strip does not fit from here: back off straight
        -- a few meters (once), the place is looked for again from there
        local distance = not self.turnBackOffDone and ADFieldPark.findTurnBackOff(self.vehicle, spot) or nil
        if distance ~= nil then
            self.turnBackOffDone = true
            module:log("field park: the turn into the cut strip does not fit from here, backing off %d m first", distance)
            print(string.format("[AD-File] %s: virage trop large pour entrer dans la bande coupee, je recule de %d m", tostring(self.vehicle:getName()), distance))
            self:startTurnBackOff(distance)
            return
        end
        if ADFieldPark.getCutWidth(spot, ADFieldPark.NARROW_STRIP) < ADFieldPark.NARROW_STRIP then
            -- the AutoDrive pathfinder (grid of the turn radius) has no room in a strip this narrow: its route
            -- would cross the standing crop and be refused after a long search
            module:log("field park: no way along the border to spot %d and the cut strip is narrow, next one", self.spotIndex)
            self:planToNextSpot()
            return
        end
    end
    self.planningTime = 0
    self.smoothingTime = nil
    self.vehicle.ad.pathFinderModule:reset()
    self.vehicle.ad.pathFinderModule:startPathPlanningTo({x = target.x, y = target.y, z = target.z}, {x = target.dirX, z = target.dirZ})
    self.state = WaitForCallTask.STATE_PATHPLANNING
end

-- the route of the AutoDrive pathfinder checked every meter over the width of the train: standing crop
-- (small forgotten patches and the border fringe excepted) is never driven through to park
function WaitForCallTask:pathCrossesCrop(wayPoints, pathFinder)
    if wayPoints == nil or #wayPoints < 2 or ADFieldPark.isPathClear == nil then
        return false
    end
    -- the same width as the pathfinder's own crop check (the tyres, no margin, behind a forage harvester):
    -- twice narrower than the body with its margin, which read the edge rows beside the route as crossed
    -- (26/10 17:48: no place found, every route refused 5 m from the entrance)
    local halfW = ADTrafficYieldModule.getWidth(self.vehicle) / 2 + (ADFieldPark.CROP_MARGIN or 0.7)
    if pathFinder ~= nil and pathFinder.getCropHalfWidth ~= nil then
        halfW = math.min(halfW, pathFinder:getCropHalfWidth())
    end
    local path = {}
    for _, wp in ipairs(wayPoints) do
        local last = path[#path]
        if last == nil or MathUtil.vector2Length(wp.x - last.x, wp.z - last.z) <= 1 then
            if last == nil then
                table.insert(path, {x = wp.x, y = wp.y, z = wp.z})
            end
        else
            -- a point every meter at most: the check reads the crop at the points of the path
            local dx, dz = wp.x - last.x, wp.z - last.z
            local length = MathUtil.vector2Length(dx, dz)
            local steps = math.ceil(length)
            for i = 1, steps do
                table.insert(path, {x = last.x + dx * i / steps, y = wp.y, z = last.z + dz * i / steps})
            end
        end
    end
    -- the first meters are where the train already stands (it came in that way): the edge rows at the
    -- entrance are not a crossing
    local startX, startZ = path[1].x, path[1].z
    local firstFree = #path
    for i = 1, #path do
        if MathUtil.vector2Length(path[i].x - startX, path[i].z - startZ) > (ADFieldPark.START_FREE or 15) then
            firstFree = i
            break
        end
    end
    if firstFree > 1 then
        local trimmed = {}
        for i = firstFree, #path do
            table.insert(trimmed, path[i])
        end
        path = trimmed
    end
    if #path < 2 then
        return false
    end
    local blocked, bx, bz, index = ADFieldPark.isPathClear(self.vehicle, path, halfW, nil, false)
    if blocked == "crop" then
        self.vehicle.ad.trafficYieldModule:log("field park: pathfinder route crosses the crop at x=%.0f z=%.0f (point %d/%d)", bx, bz, index, #path)
        return true
    end
    return false
end

-- ------------------------------------------------------------------------------------------------------------
-- Outils (helpers)
-- ------------------------------------------------------------------------------------------------------------
-- 11/11 (champ 56) : depuis le chemin, une place trouvée ne compte que si un trajet propre y mène depuis l'entrée
-- (ADFieldPark.findWayFromEntrance) : la benne ne va plus attendre au point du champ sans pouvoir entrer
function WaitForCallTask:hasWayFromEntrance(search, spots)
    if search.chopper or self.noPlaceOrigin == nil or ADFieldPark.findWayFromEntrance == nil then
        return true
    end
    local index, way = ADFieldPark.findWayFromEntrance(self.vehicle, spots, self.noPlaceOrigin)
    if index == nil then
        self.vehicle.ad.trafficYieldModule:log("field park: %d place(s) in the field, no clean way to them from the field point (x=%.0f z=%.0f)",
            #spots, self.noPlaceOrigin.x, self.noPlaceOrigin.z)
        return false
    end
    self.vehicle.ad.trafficYieldModule:log("field park: place %d reachable from the field point (%s)", index, way)
    return true
end

-- something in the trailers: the unloader comes from a harvester, not from the road
function WaitForCallTask:hasLoad()
    local trailers = AutoDrive.getAllUnits(self.vehicle)
    if trailers == nil or #trailers == 0 then
        return false
    end
    local fillLevel = AutoDrive.getAllFillLevels(trailers)
    return fillLevel ~= nil and fillLevel > 0.1
end

-- backs off straight when the nose of the tractor stands in the field, at most twice
function WaitForCallTask:startBackOff()
    local distance = WaitForCallTask.BACK_OFF_DISTANCES[self.backOffCount + 1]
    if distance == nil then
        return
    end
    local x, py, z = ADTrafficYieldModule.getPosition(self.vehicle)
    local dx, dz = ADTrafficYieldModule.getDirection(self.vehicle)
    local front = ADTrafficYieldModule.getTrainExtents(self.vehicle)
    local noseX, noseZ = x + dx * math.max(front - 0.5, 0), z + dz * math.max(front - 0.5, 0)
    if not AutoDrive.checkIsOnField(noseX, py, noseZ) then
        return
    end
    self.backOffCount = self.backOffCount + 1
    self.backOffDistance = distance
    self.backOffTimeout = WaitForCallTask.BACK_OFF_TIMEOUT
    self.backOffTargets = nil
    self.backOffStart = {x = x, z = z}
    self.backOffTime = 0
    self.vehicle.ad.trafficYieldModule:log("field park: nose in the field, backing off %d m", distance)
    self.state = WaitForCallTask.STATE_BACKING_OFF
end

-- 10/11, combine: backs off straight before the turn into the cut strip (see planToNextSpot)
function WaitForCallTask:startTurnBackOff(distance)
    local x, _, z = ADTrafficYieldModule.getPosition(self.vehicle)
    self.turnBackOff = true
    self.backOffDistance = distance
    self.backOffTimeout = WaitForCallTask.BACK_OFF_TIMEOUT
    self.backOffTargets = nil
    self.backOffStart = {x = x, z = z}
    self.backOffTime = 0
    self.state = WaitForCallTask.STATE_BACKING_OFF
end

function WaitForCallTask:hold(dt)
    self.vehicle.ad.specialDrivingModule:stopVehicle()
    self.vehicle.ad.specialDrivingModule:update(dt)
end

-- ------------------------------------------------------------------------------------------------------------
-- Fin de la tâche (WaitForCallTask:abort, WaitForCallTask:finished)
-- ------------------------------------------------------------------------------------------------------------
function WaitForCallTask:abortFieldPark()
    if ADFieldPark ~= nil then
        ADFieldPark.setParked(self.vehicle, nil)
    end
    -- called by a harvester while still planning: free the pathfinder for the next task
    if self.state == WaitForCallTask.STATE_PATHPLANNING then
        self.vehicle.ad.pathFinderModule:reset()
    end
end

function WaitForCallTask:finishedFieldPark()
    if ADFieldPark ~= nil then
        ADFieldPark.setParked(self.vehicle, nil)
    end
end

-- ------------------------------------------------------------------------------------------------------------
-- Textes du HUD (WaitForCallTask:getInfoText, WaitForCallTask:getI18nInfo)
-- ------------------------------------------------------------------------------------------------------------
-- nil : le texte d'origine d'AutoDrive
function WaitForCallTask:getFieldParkInfoText()
    if self.state == WaitForCallTask.STATE_PATHPLANNING or self.state == WaitForCallTask.STATE_DRIVING then
        return g_i18n:getText("AD_task_park_in_field")
    end
    return nil
end

-- nil : le texte d'origine d'AutoDrive (attente de l'appel)
function WaitForCallTask:getFieldParkI18nInfo()
    if self.state == WaitForCallTask.STATE_CHECK then
        return "$l10n_AD_task_look_for_spot;"
    elseif self.state == WaitForCallTask.STATE_SEARCHING then
        return "$l10n_AD_task_search_spot;" .. string.format(" (%d s)", self:getStateSeconds())
    elseif self.state == WaitForCallTask.STATE_PATHPLANNING then
        local count = self.spots ~= nil and math.min(#self.spots, ADFieldPark.MAX_TRIES) or 1
        return "$l10n_AD_task_plan_to_spot;" .. string.format(" %d/%d (%d s)", self.spotIndex or 1, count, self:getStateSeconds("spot" .. tostring(self.spotIndex)))
    elseif self.state == WaitForCallTask.STATE_DRIVING then
        return "$l10n_AD_task_go_park;"
    elseif self.state == WaitForCallTask.STATE_BACKING_OFF then
        return "$l10n_AD_task_back_off_spot;"
    elseif self.state == WaitForCallTask.STATE_TO_ENTRANCE then
        return "$l10n_AD_task_drive_to_destination;"
    end
    -- waiting
    local spot = self.parkedSpot
    if spot ~= nil and spot.roadside then
        return "$l10n_AD_task_wait_roadside;"
    elseif spot ~= nil and spot.aheadVehicle ~= nil then
        local name = spot.aheadVehicle.ad ~= nil and spot.aheadVehicle.ad.stateModule ~= nil and spot.aheadVehicle.ad.stateModule:getName() or "?"
        return "$l10n_AD_task_queued_behind; " .. tostring(name) .. ", $l10n_AD_task_waiting_call_short;"
    elseif spot ~= nil then
        return "$l10n_AD_task_parked_wait;"
    elseif self.retryTime ~= nil then
        local left = math.max(0, ADFieldPark.RETRY_DELAY - self.retryTime)
        return (self.harvesterAway and "$l10n_AD_task_no_harvester_retry;" or "$l10n_AD_task_no_spot_retry;") .. string.format(" %d s", math.ceil(left / 1000))
    elseif self.loaded then
        return "$l10n_AD_task_loaded_wait;"
    end
    return nil
end
